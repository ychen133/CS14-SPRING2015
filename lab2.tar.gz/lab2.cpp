#include <iostream>
#include <forward_list>
#include <algorithm>
#include "lab_02.h"
using namespace std;

int main()
{
    forward_list<int> list = {1, 2, 4, 9, 13, 15, 19}; //5 primes
    cout << primeCount(list) << endl;
    
    List<int> MyList;
    MyList.push_back(3);
    MyList.push_back(5);
    MyList.push_back(8);
    MyList.push_back(10);
    MyList.display();
    cout << endl;
    
    List<int> list2 = MyList.elementSwap(3);
    list2.display();
    cout << endl;
    
    forward_list<int> list1 = {1, 2, 3, 7};
    forward_list<int> list2 = {0, 10, 20};
    printLots(list2, list1);
    
    return 0;
}