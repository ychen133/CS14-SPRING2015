#include <iostream>
#include "selectionsort.h"
using namespace std;

ostream& operator<<(ostream& os, const pair<int, int>& obj)
{
    os << "(" << obj.first << "," << obj.second << ")";
    return os;
}

int main()
{
    list<int> v = {2, 4, 5, 1, 8, 9};
    //typedef vector<int> Container;
    // selectionsort<Container>(v);
    selectionsort(v);
    for(auto it = v.begin(); it != v.end(); it++)
    {
        cout << *it << " ";
    }
    cout << endl;
    
    vector< pair<int, int> > pairs;
    pairs.push_back(pair<int, int> (1,2));
    pairs.push_back(pair<int, int> (3,-1));
    pairs.push_back(pair<int, int> (-1,3));
    pairs.push_back(pair<int, int> (0,0));
    pairs.push_back(pair<int, int> (2,3));
    pairs.push_back(pair<int, int> (1,2));
    pairs.push_back(pair<int, int> (1,-2));
    pairs.push_back(pair<int, int> (8,10));
    selectionsort(pairs);
    for(auto it = pairs.begin(); it != pairs.end(); it++)
    {
        cout << *it << " ";
    }
    cout << endl;
    
    selectionsort(pairs);
    for(auto it = pairs.begin(); it != pairs.end(); it++)
    {
        cout << *it << " ";
    }
    cout << endl;
    
    list<int*> l;
    int* pntr1 = new int(3);
    int* pntr2 = new int(3);
    l.push_back(pntr1);
    l.push_back(new int(4));
    l.push_back(new int(2));
    l.push_back(pntr2);
    stablesort(l, pntr1, pntr2);
    for(auto it = l.begin(); it != l.end(); it++)
    {
        cout << *(*it) << " ";
        delete *it;
    }
    cout << endl;
    
    return 0;
}