/*
Name: Yu-Che Cheng
SID: 861142301
Date: 5/16/15
*/
#ifndef SELECTIONSORT_H
#define SELECTIONSORT_H

#include <iostream>
#include <list>
#include <vector>
#include <map>
#include <utility>
#include <algorithm>
using namespace std;


template <typename L>
void selectionsort(L &l)
{
    for(auto it = l.begin(); it != l.end(); it++)
    {
        auto selected = it;
        for(auto it2 = it; it2 != l.end(); it2++)
        {
            if(*it2 < *selected)
            {
                selected = it2;
            }
        }
        std::swap(*it, *selected);
    }
}

template <typename L>
void stablesort(L &l, int* pntr1, int* pntr2)
{
    for(auto it = l.begin(); it != l.end(); it++)
    {
        auto selected = it;
        for(auto it2 = it; it2 != l.end(); it2++)
        {
            if(*(*it2) < *(*selected))
            {
                selected = it2;
            }
        }
        std::swap(*it, *selected);
    }
    int index1 = 0;
    int index2 = 0;
    for(auto it = l.begin(); *it != pntr1; it++)
    {
        index1++;
    }
    for(auto it = l.begin(); *it != pntr2; it++)
    {
        index2++;
    }
    cout << index1 << " " << index2 << endl;
}
#endif