#include <iostream>
#include <queue>
#include <utility>
#include "lab4.H"
using namespace std;

int main(int argc, char* argv[])
{
    if(argc != 2)
    {
        cout << "Error: Insufficient argument count." << endl;
    }
    
    int k = atoi(argv[1]);
    
    cout << "pre-order" << endl;
    calculatePreorder(2, 1, k);
    calculatePreorder(3, 1, k);
    
    cout << "post-order" << endl;
    calculatePostorder(2, 1, k);
    calculatePostorder(3, 1, k);
    
    cout << "sorted" << endl;
    priority_queue< pair<int, int> > mypq1;
    priority_queue< pair<int, int> > mypq2;
    calculateSorted(2, 1, k, mypq1);
    calculateSorted(3, 1, k, mypq2);
    printSorted(mypq1, mypq2);
    
    return 0;
}